package Test;

public class Test {
	public static void main(String[] args) {
		System.out.println(Integer.MAX_VALUE);
		System.err.println("ahhhh");;
	}
}
