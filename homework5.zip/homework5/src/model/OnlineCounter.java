package model;

import java.io.Serializable;

public class OnlineCounter implements Serializable{
	private int total=0;
	private int visitor=0;
	private int login=0;
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getVisitor() {
		return visitor;
	}
	public void setVisitor(int visitor) {
		this.visitor = visitor;
	}
	public int getLogin() {
		return login;
	}
	public void setLogin(int login) {
		this.login = login;
	}
	

}
