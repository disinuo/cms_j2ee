package tool;
public enum Sex {
	MALE,FEMALE
}
